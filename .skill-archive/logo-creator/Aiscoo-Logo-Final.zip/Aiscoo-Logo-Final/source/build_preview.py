"""Build a self-contained preview.html: every asset is inlined, so the single file can be shared."""
import base64
import html
import re
from pathlib import Path

OUT = Path(__file__).parent


def data_uri(name):
    return "data:image/svg+xml;base64," + base64.b64encode((OUT / name).read_bytes()).decode()


def img(name, style=""):
    return f'<img src="{data_uri(name)}" alt="{name}" style="{style}">'


def splash(theme):
    s = (OUT / "splash.html").read_text()
    if theme == "dark":
        # Force the dark branch regardless of the viewer's system theme.
        s = s.replace("@media (prefers-color-scheme:dark){", "@media all{")
    else:
        s = re.sub(r"@media \(prefers-color-scheme:dark\)\{.*?\}\}", "", s, count=1, flags=re.S)
    return f'<iframe srcdoc="{html.escape(s, quote=True)}" title="启动页 {theme}"></iframe>'


def sizes(name):
    return "".join(f'<figure>{img(name, f"width:{w}px")}<figcaption>{w}px</figcaption></figure>'
                   for w in (128, 64, 32, 16))


CSS = """
:root{color-scheme:light}
body{margin:0;background:#E9EBEF;font:14px/1.5 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;color:#3F4652}
main{max-width:1120px;margin:0 auto;padding:32px 24px 48px;display:grid;gap:28px}
header h1{margin:0;font-size:22px;color:#121317}
header p{margin:4px 0 0;color:#6B7280}
section{display:grid;gap:12px}
h2{margin:0;font-size:15px;color:#121317}
.note{margin:0;color:#6B7280;font-size:13px}
.row{display:grid;gap:16px;grid-template-columns:1fr 1fr}
.row3{display:grid;gap:16px;grid-template-columns:repeat(3,1fr)}
.card{background:#fff;border-radius:16px;overflow:hidden;display:grid;place-items:center;min-height:120px}
.card.dark{background:#1C1C1E}
.card img{display:block;max-width:100%}
.wide img{width:100%}
iframe{display:block;width:100%;height:280px;border:0;border-radius:16px;background:#fff}
.sizes{display:flex;gap:28px;align-items:flex-end;padding:20px}
figure{margin:0;display:grid;justify-items:center;gap:6px}
figcaption{font-size:12px;color:#9CA3AF}
table{border-collapse:collapse;background:#fff;border-radius:16px;overflow:hidden;font-size:13px}
td,th{padding:10px 14px;text-align:left;border-bottom:1px solid #EEF0F3}
th{color:#121317;font-weight:600}
code{font:12px ui-monospace,SFMono-Regular,Menlo,monospace;color:#121317}
@media (max-width:720px){.row,.row3{grid-template-columns:1fr}}
"""

FILES = [
    ("动效应用 Logo", "ai-lockup-anim-light.svg / ai-lockup-anim-dark.svg"),
    ("静态应用 Logo", "ai-lockup-light.svg / ai-lockup-dark.svg，PNG：export/lockup-*@2x.png"),
    ("启动页", "splash.html（动效：ai-mark-anim.svg / ai-mark-anim-white.svg）"),
    ("启动页静态 Logo（收起）", "ai-mark-tucked.svg / ai-mark-tucked-white.svg，PNG：export/mark-ai-tucked-*.png"),
    ("应用图标", "export/Aiscoo.icns / export/Aiscoo.ico / export/icon-1024.png / export/icon-dark-1024.png"),
]


def main():
    rows = "".join(f"<tr><td>{a}</td><td><code>{html.escape(b)}</code></td></tr>" for a, b in FILES)
    page = f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Aiscoo Logo 预览</title>
<style>{CSS}</style></head><body><main>
<header><h1>Aiscoo Logo</h1><p>a 是躲在 i 后面的 AI：探出、张望、看圆点、圆点跳动、眨眼、缩回，8 秒一轮，缩回后停约 3.7 秒。</p></header>

<section><h2>应用 Logo · 动效</h2>
<div class="row"><div class="card wide">{img("ai-lockup-anim-light.svg")}</div>
<div class="card wide dark">{img("ai-lockup-anim-dark.svg")}</div></div></section>

<section><h2>启动页</h2><p class="note">首帧和"减少动态效果"时显示收起状态。</p>
<div class="row">{splash("light")}{splash("dark")}</div></section>

<section><h2>启动页静态 Logo · 收起状态</h2>
<div class="row"><div class="card">{img("ai-mark-tucked.svg", "width:180px")}</div>
<div class="card dark">{img("ai-mark-tucked-white.svg", "width:180px")}</div></div></section>

<section><h2>应用图标</h2>
<div class="row"><div class="card">{img("ai-icon.svg", "width:260px")}</div>
<div class="card">{img("ai-icon-dark.svg", "width:260px")}</div></div>
<div class="card"><div class="sizes">{sizes("ai-icon.svg")}{sizes("ai-icon-dark.svg")}</div></div></section>

<section><h2>应用 Logo · 静态</h2>
<div class="row"><div class="card wide">{img("ai-lockup-light.svg")}</div>
<div class="card wide dark">{img("ai-lockup-dark.svg")}</div></div></section>

<section><h2>文件清单</h2><p class="note">路径相对于本文件所在目录。</p>
<table><tr><th>用途</th><th>文件</th></tr>{rows}</table></section>
</main></body></html>
"""
    (OUT / "preview.html").write_text(page)
    print(f"preview.html {len(page) // 1024} KB")


if __name__ == "__main__":
    main()
